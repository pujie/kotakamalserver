<div class="page-sidebar nav-collapse collapse">
    <!-- BEGIN SIDEBAR MENU -->
    <ul class="page-sidebar-menu">
        <li>
            <!-- BEGIN SIDEBAR TOGGLER BUTTON -->
            <div class="sidebar-toggler hidden-phone"></div>
            <!-- BEGIN SIDEBAR TOGGLER BUTTON -->
        </li>
        <li class="start ">
            <a href="index.html">
            <i class="icon-home"></i> 
            <span class="title">Outlets</span>
            </a>
        </li>
    </ul>
    <!-- END SIDEBAR MENU -->
</div>
